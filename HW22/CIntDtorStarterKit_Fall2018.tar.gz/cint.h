// ============================================================================
// File: cint.h (Fall 2018)
// ============================================================================
// Programmer: ???
// Date: ???
// Class: CSCI 123 ("Intro to Programming Using C++")
// Time: ???
// Instructor: Prof. Edwards
//
// Description:
//      ???
// ============================================================================

#ifndef CINT_HEADER
#define CINT_HEADER

// class declaration
class   CInt
{
public:
    // constructor and destructor
    CInt(int intVal) { ??? }
    ~CInt() { ??? }

    // accessor and mutator functions
    int     GetInt() const { ??? }
    void    SetInt(int  intVal) { ??? }

private:
    int     *m_intPtr;
};

#endif  // CINT_HEADER
