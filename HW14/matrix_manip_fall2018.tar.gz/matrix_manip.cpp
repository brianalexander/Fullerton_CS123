// ============================================================================
// File: matrix_manip.cpp (Fall 2017)
// ============================================================================
// Programmer: ???
// Date: ???
// Class: CSCI 123 ("Intro to Programming Using C++")
// Time: ???
// Instructor: Mr. Edwards
// Project: Matrix Manipulation
//
// Description:
//  This program allows the user to manipulate a two-dimensional array of ints.
//  A menu is presented in a loop, and the user has the option to:
//  
//     1) set all the elements of the 2D array to a user-entered value;
//     2) display the 2D array to stdout (using a user-entered field width);
//     3) display the sum of all the ints in the 2D array
//     4) quit the program.

// ============================================================================

#include    <iostream>
#include    <iomanip>
using namespace std;


// defined constants
const   int         ROWS = 3;
const   int         COLS = 5;
const   int         WIDTH = 5;


// function prototypes
void    DispMatrix(int  matrix[][COLS], int  numRows, int  width);
void    DispMenu();
int     GetMatrixSum(int  matrix[][COLS], int  numRows);
void    InitMatrix(int  matrix[][COLS], int  numRows, int  initVal);


// ==== main ==================================================================
// 
// ============================================================================

int     main()
{
    bool        bContinue = true;
    int         myInts[ROWS][COLS];
    char        selection;

    // announce ourselves to the user
    cout << "Welcome to the Matrix Manipulation Program!" << endl;

    // loop, display the menu and handle user selections until it's time to 
    // quit!
    do  {
        // display the menu and get the user selection
        DispMenu();
        cin >> selection;

        // switch on the user's selection to call the appropriate function;
        // if the function to call requires additional input from the user, 
        // get it here in the switch, not in the called function

        // PUT YOUR CODE HERE...
        ???
        ???
        ???


        } while (bContinue);

    return 0;

}  // end of "main"



// ==== DispMenu ==============================================================
// 
// This function is responsible for writing the menu options to stdout for the
// user.
// 
// Input:  nothing
// 
// Output: nothing
// 
// ============================================================================

void    DispMenu()
{
    // display the menu
    cout << endl << "Please select one of the following options:\n";
    cout << " I)nitialize the matrix" << endl;
    cout << " D)isplay the matrix" << endl;
    cout << " G)et the sum of all values in the matrix" << endl;
    cout << " Q)uit" << endl;  
    cout << "=> ";

}  // end of "DispMenu"



// ==== FlushStdin ============================================================
// 
// This function discards any data that is currently in the stdin buffer and
// also clears the bit flags for the stream object, so that the caller can
// proceed to read from a valid and empty input stream.
// 
// Input:
//     Nothing
// 
// Output:
//     Nothing
// 
// ============================================================================

void    FlushStdin()
{
    char    inChar;

    cin.clear();
    do  {
        cin.get(inChar);
        if (('\n' == inChar) || (cin.eof()))
            {
            break;
            }

        } while (true);

}  // end of "FlushStdin"
